package exam;

import java.util.Scanner;

public class ERP extends Major 
{

	public ERP()
	{
		System.out.println("Welcome to Patient Management ERP");
	}

	public static void main(String[] args) 
	{
		String p;
		ERP erp=new ERP();
    Scanner sc= new Scanner(System.in);      
	System.out.println("Enter UserName");  
	String uName= sc.nextLine();  
	System.out.println("Enter Password");  
	String pWord= sc.nextLine(); 
	
	boolean loginStatus= erp.login(uName, pWord);
	if (loginStatus==true)
	{
		System.out.println("1.Enter into Patient Repository");
		System.out.println("2.Assign Duty Doctor");
		System.out.println("3.Show Duty Doctor");
		String p2 = sc.nextLine();
	    
	if (p2.equals("1"))	
	{
		System.out.println("-------------------------------");
		erp.person1();
		System.out.println("-------------------------------");
		erp.person2();
		System.out.println("-------------------------------");
		erp.person3();
		System.out.println("-------------------------------");
		erp.person4();
		System.out.println("-------------------------------");
	  
		  try
		    {	
		System.out.println("Enter the Patient ID :");
	    p = sc.nextLine();
	    int id = Integer.parseInt(p);
	  
	   switch(id) 
	   {
	   case 1001:
		   erp.person1();
		   break;
	   case 1002:
		   erp.person2();
		   break;
	   case 1003:
		   erp.person3();
		   break;
	   case 1004:
		   erp.person4();
		   break;
		   default :
			   System.out.println("There is no patient available for that ID :"+p);   
	  
	   	} 
	    }
	    catch (Exception e)
		{
			System.out.println("ID Should not be a Char");
		}
		
	}
	
	if(p2.equals("2"))
	{
		System.out.println("Enter Doctor Name");  
		String dName= sc.nextLine();
		
		erp.setDoc(dName);
		
		System.out.println("Duty Doctor Name is "+erp.getDocName());
	}
	
	if(p2.equals("3"))
	{
	System.out.println("Duty Doctor Name is "+erp.getDocName());
	}
	}
	else
	{
		System.out.println("Invalid Cerdientials");
	}
    sc.close();   
    } 

	}


