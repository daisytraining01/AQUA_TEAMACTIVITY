package exam;

public interface Ierp {

	public abstract void person1();
	public abstract void person2();
	public abstract void person3();
	public abstract void person4();
}
