package exam;

import java.util.ArrayList;

public class Major implements Ierp{
	
	public boolean r1;
	private String docName;

	public boolean login(String a,String b)
	{
		ArrayList<String> list = new ArrayList<>(); 
		ArrayList<String> list1 = new ArrayList<>(); 
		r1 = false;
	    list.add("user1"); list.add("user2"); list.add("user3"); 
	    list1.add("pass1"); list1.add("pass2");  list1.add("pass3");     
	    
	    int p= list.indexOf(a);
	    String s=list.get(p);
	    String s1=list1.get(p);
	   if((s.equals(a)) && (s1.equals(b)))
	   {
		   r1=true;
	   }
		return r1;
		}



	public void person1() 
	{
		String name = "Haroon";
		int age = 26;
		int id = 1001;
		String blood = "B+ve";
		String Disease ="Cough";
		System.out.println("Patient Name :"+name);
		System.out.println("Patient Age :"+age);
		System.out.println("Patient ID :"+id);
		System.out.println("Patient Bloood Group :"+blood);
		System.out.println("Patient Disease :"+Disease);
	}

	public void person2() {
		
		String name = "Mani";
		int age = 26;
		int id = 1002;
		String blood = "O-ve";
		String Disease ="Anemesia";
		System.out.println("Patient Name :"+name);
		System.out.println("Patient Age :"+age);
		System.out.println("Patient ID :"+id);
		System.out.println("Patient Bloood Group :"+blood);
		System.out.println("Patient Disease :"+Disease);
		
	}

	public void person3() {
		String name = "Vicky";
		int age = 2;
		int id = 1003;
		String blood = "A+ve";
		String Disease ="Sinus";
		System.out.println("Patient Name :"+name);
		System.out.println("Patient Age :"+age);
		System.out.println("Patient ID :"+id);
		System.out.println("Patient Bloood Group :"+blood);
		System.out.println("Patient Disease :"+Disease);
		
	}

	public void person4() {
		String name = "Raj";
		int age = 24;
		int id = 1004;
		String blood = "AB+ve";
		String Disease ="Headache";
		System.out.println("Patient Name :"+name);
		System.out.println("Patient Age :"+age);
		System.out.println("Patient ID :"+id);
		System.out.println("Patient Bloood Group :"+blood);
		System.out.println("Patient Disease :"+Disease);
		
	}	
	
	 public void setDoc(String name1){
	        docName = name1;
	    }
	 public String getDocName(){
	        return docName;
	    }

}
